# /root/model-server/main.py
# 最终版本: 实现了异步任务接口和文件系统驱动的状态查询

from fastapi import FastAPI, BackgroundTasks, HTTPException
from pydantic import BaseModel
import uuid
import os
import json
from urllib.parse import unquote
from model_utils import run_model_pipeline

app = FastAPI(title="Yigui Model Server v2.0")

# Pydantic模型，定义了从App接收的输入数据结构
class ModelInput(BaseModel):
    gender: str
    height: float
    weight: float
    nickname: str
    chest_ratio: float = 1.0
    waist_ratio: float = 1.0
    thigh_ratio: float = 1.0

# 异步任务触发接口
@app.post("/generate")
async def generate_model_async(input: ModelInput, background_tasks: BackgroundTasks):
    task_id = str(uuid.uuid4())
    
    # 将我们耗时的 "两步走" 流程添加到后台任务队列
    background_tasks.add_task(
        run_model_pipeline,
        task_id=task_id,
        gender=input.gender,
        height=input.height,
        weight=input.weight,
        nickname=input.nickname,
        chest_ratio=input.chest_ratio,
        waist_ratio=input.waist_ratio,
        thigh_ratio=input.thigh_ratio
    )
    # 立即返回task_id，让App可以开始轮询
    return {"task_id": task_id, "status": "processing"}

# 任务状态查询接口
@app.get("/task_status/{nickname}/{task_id}")
def get_task_status(nickname: str, task_id: str):
    # URL解码，以处理包含空格等特殊字符的昵称
    decoded_nickname = unquote(nickname)
    
    base_dir = "/root/model-server/generated_models"
    user_task_dir = os.path.join(base_dir, f"{decoded_nickname}_models", "tasks")
    status_file_path = os.path.join(user_task_dir, f"{task_id}.json")

    if not os.path.exists(status_file_path):
        # 如果状态文件还未创建，说明任务仍在队列中或刚开始，返回processing
        return {"task_id": task_id, "status": "processing"}

    try:
        with open(status_file_path, 'r') as f:
            data = json.load(f)
        # 直接返回状态文件中的内容 (可能是 processing, completed, 或 failed)
        return data
    except Exception as e:
        # 如果文件读取失败，返回错误状态
        return {"task_id": task_id, "status": "error", "detail": str(e)}