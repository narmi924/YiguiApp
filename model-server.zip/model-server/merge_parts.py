# /root/model-server/merge_parts.py
import bpy
import sys
import os

print("--- [Merger] 合并脚本启动 ---")

# --- 1. 参数解析 ---
# 接收一个输出路径，以及任意数量的输入路径
argv = sys.argv
argv = argv[argv.index("--") + 1:]
if len(argv) < 2:
    print("错误: 至少需要1个输入文件和1个输出文件。")
    sys.exit(1)

output_path = argv[0]
input_paths = argv[1:]

print(f"准备合并 {len(input_paths)} 个文件到 {output_path}")

# --- 2. 导入所有部件 ---
bpy.ops.wm.read_homefile(use_empty=True)
for path in input_paths:
    if os.path.exists(path):
        bpy.ops.import_scene.gltf(filepath=path)
    else:
        print(f"警告: 输入文件未找到，已跳过: {path}")

# --- 3. 合并所有网格 ---
meshes_to_join = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']
if len(meshes_to_join) > 1:
    bpy.context.view_layer.objects.active = meshes_to_join[0]
    for obj in meshes_to_join:
        obj.select_set(True)
    bpy.ops.object.join()
    print("所有部件网格已合并。")
    final_object = bpy.context.active_object
elif len(meshes_to_join) == 1:
    final_object = meshes_to_join[0]
else:
    final_object = None

# --- 4. 导出最终成品 ---
if final_object:
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    bpy.ops.object.select_all(action='DESELECT')
    final_object.select_set(True)
    bpy.ops.export_scene.gltf(
        filepath=output_path,
        export_format='GLB',
        use_selection=True
    )
    print(f"--- 合并成功，最终文件已导出到: {output_path} ---")
else:
    print("错误：没有可供导出的物体。")