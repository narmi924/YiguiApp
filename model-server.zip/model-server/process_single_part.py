# /root/model-server/process_single_part.py
# 最终版本: 接收单个部件，使用CoreML参数进行精细化缩放，并进行可靠的烘焙

import bpy
import sys
import os

# --- 1. 参数解析 ---
argv = sys.argv
argv = argv[argv.index("--") + 1:]
if len(argv) < 7: sys.exit(1)
model_path, output_path = argv[0], argv[1]
height, weight = float(argv[2]), float(argv[3])
chest_ratio, waist_ratio, thigh_ratio = float(argv[4]), float(argv[5]), float(argv[6])

# --- 2. 导入与查找 ---
bpy.ops.wm.read_homefile(use_empty=True)
bpy.ops.import_scene.gltf(filepath=model_path)
armature = next((obj for obj in bpy.context.scene.objects if obj.type == 'ARMATURE'), None)
all_meshes = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']
if not armature or len(all_meshes) != 1: sys.exit(1)
mesh_obj = all_meshes[0]

# --- 3. 最终的、以CoreML为绝对主导的微调逻辑 v3.2 ---
print(f"--- 接收到的CoreML原始比例: C={chest_ratio:.4f}, W={waist_ratio:.4f}, T={thigh_ratio:.4f} ---")

# A. 参数归一化 (我们只使用这一层来处理CoreML数据)
# 根据您的真实数据，标准身材的比例值在0.3-0.5之间，我们取0.45为基准
BASE_RATIO = 0.45 
# 关键修正：大幅降低敏感度，确保所有变形都是“微调”
SENSITIVITY = 0.5 

# 将CoreML的比例值，转换为以1.0为基准的、变化幅度很小的缩放因子
waist_scale = 1.0 + (waist_ratio - BASE_RATIO) * SENSITIVITY
chest_scale = 1.0 + (chest_ratio - BASE_RATIO) * SENSITIVITY
thigh_scale = 1.0 + (thigh_ratio - BASE_RATIO) * SENSITIVITY
print(f"--- 归一化后的微调缩放因子: C={chest_scale:.4f}, W={waist_scale:.4f}, T={thigh_scale:.4f} ---")


# B. 身高调整（物体模式 - 保持不变）
STANDARD_HEIGHT = 175.0
height_ratio = height / STANDARD_HEIGHT
armature.scale = (height_ratio, height_ratio, height_ratio)

# C. 胖瘦调整（姿态模式）
bpy.context.view_layer.objects.active = armature
bpy.ops.object.mode_set(mode='POSE')

# 反向缩放根骨骼以抵消父级缩放带来的影响
root_bone = armature.pose.bones.get("root")
if root_bone:
    inverse_height_ratio = 1.0 / height_ratio if height_ratio != 0 else 1.0
    root_bone.scale = (inverse_height_ratio, inverse_height_ratio, inverse_height_ratio)

# 腰部控制
for name in ["spine_01", "spine_02"]:
    bone = armature.pose.bones.get(name)
    if bone: bone.scale[0] = waist_scale; bone.scale[2] = waist_scale

# 胸腔控制
for name in ["spine_03", "spine_04"]:
    bone = armature.pose.bones.get(name)
    if bone: bone.scale[0] = chest_scale; bone.scale[2] = chest_scale

# 腿部控制 (大腿)
for name in ["thigh_l", "thigh_r"]:
    bone = armature.pose.bones.get(name)
    if bone: bone.scale[0] = thigh_scale; bone.scale[2] = thigh_scale

# 小腿控制 (核心修正：使用衰减系数，让其变化比大腿平缓)
calf_dampening_factor = 0.8 # 小腿只产生大腿80%的粗细变化
calf_scale = 1.0 + (thigh_scale - 1.0) * calf_dampening_factor
for name in ["calf_l", "calf_r"]:
    bone = armature.pose.bones.get(name)
    if bone: bone.scale[0] = calf_scale; bone.scale[2] = calf_scale

# 臀部平滑过渡
pelvis = armature.pose.bones.get("pelvis")
if pelvis:
    pelvis_scale = 1.0 + (waist_scale - 1.0 + thigh_scale - 1.0) / 2.0
    pelvis.scale[0] = pelvis_scale; pelvis.scale[2] = pelvis_scale

bpy.ops.object.mode_set(mode='OBJECT')
print("--- 最终美学微调缩放应用完成 ---")

# --- 4. 烘焙与清理 (使用在单体模型上被验证过的旧版可靠流程) ---
bpy.context.view_layer.objects.active = armature
mesh_obj.select_set(True)
armature.select_set(True)
bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
bpy.ops.object.convert(target='MESH')
bpy.data.objects.remove(bpy.data.objects.get(armature.name), do_unlink=True)

# --- 5. 导出 ---
os.makedirs(os.path.dirname(output_path), exist_ok=True)
final_mesh_to_export = bpy.data.objects.get(mesh_obj.name)
if final_mesh_to_export:
    bpy.ops.object.select_all(action='DESELECT')
    final_mesh_to_export.select_set(True)
    bpy.ops.export_scene.gltf(filepath=output_path, export_format='GLB', use_selection=True)
    print(f"--- 部件成功处理并导出到: {output_path} ---")