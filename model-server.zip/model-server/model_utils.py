# /root/model-server/model_utils.py
import os
import subprocess
import json

def run_blender_process(command, task_name):
    """运行一个Blender进程并检查结果"""
    print(f"--- 开始子任务: {task_name} ---")
    try:
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        print(f"--- 子任务 {task_name} 成功 ---")
        return "success"
    except subprocess.CalledProcessError as e:
        error_message = f"failed: {e.stderr}"
        print(f"--- 子任务 {task_name} 失败: {error_message} ---")
        raise RuntimeError(error_message)

def run_model_pipeline(task_id: str, gender: str, height: float, weight: float, nickname: str, chest_ratio: float, waist_ratio: float, thigh_ratio: float):
    base_dir = "/root/model-server"
    timestamp = task_id # 使用task_id作为时间戳，保证文件名的唯一性
    user_generated_dir = os.path.join(base_dir, "generated_models", f"{nickname}_models")
    task_status_dir = os.path.join(user_generated_dir, "tasks")
    os.makedirs(task_status_dir, exist_ok=True)
    status_file_path = os.path.join(task_status_dir, f"{task_id}.json")

    intermediate_files = []
    try:
        # --- 1. 定义所有部件及其路径 ---
        if gender == 'male':
            assets_dir = os.path.join(base_dir, "base_models", "male")
            parts_to_process = {"body": "base_male_model.glb", "shirt": "shirt_default.glb", "pants": "pant_default.glb"}
        elif gender == 'female':
            assets_dir = os.path.join(base_dir, "base_models", "female")
            parts_to_process = {"body": "base_female_model.glb", "shirt": "sweatshirt_default.glb", "pants": "shorts_default.glb"}
        else:
            raise ValueError(f"不支持的性别: {gender}")

        # --- 2. [阶段一] 串行生成所有变形好的部件 ---
        part_processor_script = os.path.join(base_dir, "process_single_part.py")
        part_output_paths = []
        for part_name, asset_filename in parts_to_process.items():
            input_path = os.path.join(assets_dir, asset_filename)
            output_filename = f"part_{part_name}_{timestamp}.glb"
            output_path = os.path.join(user_generated_dir, output_filename)
            part_output_paths.append(output_path)
            intermediate_files.append(output_path)
            command = ["blender", "--background", "--python", part_processor_script, "--", input_path, output_path, str(height), str(weight), str(chest_ratio), str(waist_ratio), str(thigh_ratio)]
            run_blender_process(command, f"scale_{part_name}")

        # --- 3. [阶段二] 将所有部件合并成一个最终文件 ---
        final_output_filename = f"final_{timestamp}.glb"
        final_output_path = os.path.join(user_generated_dir, final_output_filename)
        merger_script_path = os.path.join(base_dir, "merge_parts.py")
        merge_command = ["blender", "--background", "--python", merger_script_path, "--", final_output_path] + part_output_paths
        run_blender_process(merge_command, "merge_all")

        # --- 4. 任务成功 ---
        final_url = f"https://yiguiapp.xyz/models/{nickname}_models/{final_output_filename}"
        result_data = {"status": "completed", "url": final_url} # 返回单个URL
        print(f"[{task_id}] 所有流程成功完成。")

    except Exception as e:
        result_data = {"status": "failed", "error_message": str(e)}
        print(f"[{task_id}] 任务失败: {str(e)}")
    
    finally:
        # --- 5. [阶段三] 清理所有临时的部件文件 ---
        print("--- [阶段三] 开始清理中间文件 ---")
        for temp_file in intermediate_files:
            if os.path.exists(temp_file):
                os.remove(temp_file); print(f"已删除临时文件: {temp_file}")
    
    # --- 写入最终状态文件 ---
    with open(status_file_path, 'w') as f:
        json.dump(result_data, f)