from fastapi import FastAPI, HTTPException, Depends
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import Optional
from sqlalchemy.orm import Session
from db import get_db, User, Avatar
from email_utils import send_email_code
import jwt
import random
import base64
import os
from datetime import datetime, timedelta

app = FastAPI()
# 挂载静态文件目录
app.mount("/avatars", StaticFiles(directory="avatars"), name="avatars")

SECRET_KEY = "your_jwt_secret_key"
# 头像处理函数
def save_avatar(user_id: int, nickname: str, avatar_data: str, db: Session):
    """保存用户头像到文件系统和数据库"""
    try:
        # 解析base64数据
        if avatar_data.startswith("data:image"):
            # 移除data URI前缀
            avatar_data = avatar_data.split(",")[1]
        
        # 解码base64数据
        image_data = base64.b64decode(avatar_data)
        
        # 创建用户头像目录
        user_avatar_dir = f"/var/www/avatars/{nickname}_avatar"
        os.makedirs(user_avatar_dir, exist_ok=True)
        
        # 生成文件名（使用时间戳）
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"avatar_{timestamp}.jpg"
        file_path = os.path.join(user_avatar_dir, filename)
        
        # 保存图片文件
        with open(file_path, "wb") as f:
            f.write(image_data)
        
        # 将之前的头像设为非当前
        db.query(Avatar).filter_by(user_id=user_id).update({"is_current": 0})
        
        # 保存头像记录到数据库
        avatar_record = Avatar(
            user_id=user_id,
            filename=filename,
            file_path=file_path,
            is_current=1
        )
        db.add(avatar_record)
        db.commit()
        
        print(f"头像保存成功: {file_path}")
        return file_path
    except Exception as e:
        print(f"保存头像失败: {e}")
        return None

def get_current_avatar_url(user_id: int, db: Session):
    """获取用户当前头像URL"""
    avatar = db.query(Avatar).filter_by(user_id=user_id, is_current=1).first()
    if avatar:
        # 构建正确的头像URL路径
        user_avatar_dir = f"{avatar.user.nickname}_avatar"
        return f"https://yiguiapp.xyz/avatars/{user_avatar_dir}/{avatar.filename}"
    return None
ALGORITHM = "HS256"

# 注册模型
class RegisterRequest(BaseModel):
    email: str
    password: str
    nickname: str
    gender: Optional[str] = "male"  # 默认为男性

# 验证模型
class VerifyRequest(BaseModel):
    email: str
    code: str

# 登录模型
class LoginRequest(BaseModel):
    email: str
    password: str

# 通用返回模型
class TokenResponse(BaseModel):
    token: str
    message: str

# 用户信息返回模型
class UserInfoResponse(BaseModel):
    email: str
    nickname: str
    height: Optional[int] = None
    weight: Optional[int] = None
    avatar_url: Optional[str] = None
    gender: str = "male"  # 添加性别字段

# 更新用户信息请求模型
# 更新用户信息响应模型（包含新token）
class UpdateUserInfoResponse(BaseModel):
    message: str
    new_token: Optional[str] = None  # 如果更新了关键信息，返回新token

class UpdateUserInfoRequest(BaseModel):
    token: str
    height: Optional[int] = None
    weight: Optional[int] = None
    avatar_url: Optional[str] = None
    gender: Optional[str] = None  # 允许更新性别（仅对新用户）
    nickname: Optional[str] = None  # 允许更新昵称（仅对新用户）

# 注册接口
@app.post("/register")
def register(request: RegisterRequest, db: Session = Depends(get_db)):
    # 检查邮箱唯一
    existing = db.query(User).filter_by(email=request.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="邮箱已注册")

    # 检查 nickname 唯一
    existing_nick = db.query(User).filter_by(nickname=request.nickname).first()
    if existing_nick:
        raise HTTPException(status_code=400, detail="昵称已被使用")

    # 验证性别值
    if request.gender not in ["male", "female"]:
        raise HTTPException(status_code=400, detail="性别值无效，必须是male或female")

    # 生成 6 位验证码
    code = str(random.randint(100000, 999999))
    success = send_email_code(request.email, code)
    if not success:
        raise HTTPException(status_code=500, detail="验证码发送失败")

    # 插入数据库，包含性别信息
    user = User(
        email=request.email,
        password=request.password,
        verification_code=code,
        verified=False,
        nickname=request.nickname,
        gender=request.gender
    )
    db.add(user)
    db.commit()
    db.refresh(user)

    # 创建用户专属模型目录
    import os
    model_dir = os.path.join("/root/model-server/generated_models", f"{user.nickname}_models")
    os.makedirs(model_dir, exist_ok=True)

    return {"message": "注册成功，验证码已发送至邮箱"}

# 验证邮箱验证码
@app.post("/verify")
def verify(request: VerifyRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(email=request.email).first()
    if not user:
        raise HTTPException(status_code=404, detail="用户不存在")

    if user.verification_code != request.code:
        raise HTTPException(status_code=400, detail="验证码错误")

    user.verified = True
    db.commit()
    return {"message": "验证成功"}

# 登录接口 - 修改token生成逻辑，包含nickname和gender
@app.post("/login", response_model=TokenResponse)
def login(request: LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(email=request.email, password=request.password).first()
    if not user:
        raise HTTPException(status_code=401, detail="邮箱或密码错误")
    if not user.verified:
        raise HTTPException(status_code=403, detail="邮箱未验证")

    # 在token中包含用户ID、邮箱、昵称和性别
    token_payload = {
        "user_id": user.id,
        "email": user.email,
        "nickname": user.nickname,
        "gender": user.gender
    }
    token = jwt.encode(token_payload, SECRET_KEY, algorithm=ALGORITHM)
    return TokenResponse(token=token, message="登录成功")

# 获取用户信息接口
@app.get("/user_info")
def get_user_info(token: str, db: Session = Depends(get_db)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("user_id")
        
        user = db.query(User).filter_by(id=user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="用户不存在")
        
        return {
            "email": user.email,
            "nickname": user.nickname,
            "height": getattr(user, "height", None),
            "weight": getattr(user, "weight", None),
            "avatar_url": get_current_avatar_url(user.id, db) or getattr(user, "avatar_url", None),
            "gender": getattr(user, "gender", "male")  # 添加性别字段
        }
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="无效的token")

# 更新用户信息接口
@app.post("/update_user_info", response_model=UpdateUserInfoResponse)
def update_user_info(request: UpdateUserInfoRequest, db: Session = Depends(get_db)):
    try:
        payload = jwt.decode(request.token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("user_id")
        
        user = db.query(User).filter_by(id=user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="用户不存在")
        
        # 记录是否更新了关键信息（需要重新生成token的信息）
        token_info_updated = False
        
        # 更新用户信息
        if request.height is not None:
            user.height = request.height
            print(f"更新身高: {request.height}")
            
        if request.weight is not None:
            user.weight = request.weight
            print(f"更新体重: {request.weight}")
            
        if request.avatar_url is not None:
            # 保存头像到文件系统和数据库
            avatar_path = save_avatar(user.id, user.nickname, request.avatar_url, db)
            if avatar_path:
                # 更新用户表中的avatar_url为新的URL
                user.avatar_url = get_current_avatar_url(user.id, db)
                print(f"更新头像: {user.avatar_url}")
            else:
                print("头像保存失败")
            
        if request.gender is not None and request.gender in ["male", "female"]:
            old_gender = user.gender
            user.gender = request.gender
            token_info_updated = True
            print(f"更新性别: {old_gender} -> {request.gender}")
            
        if request.nickname is not None and request.nickname.strip():
            old_nickname = user.nickname
            user.nickname = request.nickname.strip()
            token_info_updated = True
            print(f"更新昵称: {old_nickname} -> {request.nickname.strip()}")
            
        db.commit()
        
        # 如果更新了关键信息，生成新的token
        new_token = None
        if token_info_updated:
            token_payload = {
                "user_id": user.id,
                "email": user.email,
                "nickname": user.nickname,
                "gender": user.gender
            }
            new_token = jwt.encode(token_payload, SECRET_KEY, algorithm=ALGORITHM)
            print(f"生成新token，包含更新后的信息: nickname={user.nickname}, gender={user.gender}")
        
        return UpdateUserInfoResponse(
            message="用户信息更新成功",
            new_token=new_token
        )
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="无效的token") 