from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.orm import Session
from sqlalchemy import DateTime, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime

# 数据库配置
MYSQL_USER = "yigui_user"
MYSQL_PASS = "777077"
MYSQL_HOST = "localhost"
MYSQL_DB = "yigui"

# 连接字符串
SQLALCHEMY_DATABASE_URL = f"mysql+pymysql://{MYSQL_USER}:{MYSQL_PASS}@{MYSQL_HOST}/{MYSQL_DB}"

# 引擎与会话工厂
engine = create_engine(SQLALCHEMY_DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 基类
Base = declarative_base()

# 会话依赖函数（用于 FastAPI 的 Depends）
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 用户表模型
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), nullable=False, unique=True)
    nickname = Column(String(64), nullable=False, unique=True) 
    password = Column(String(255), nullable=False)
    verification_code = Column(String(10))
    verified = Column(Integer, default=0)
    # 新增字段
    height = Column(Integer, nullable=True)  # 身高(cm)
    weight = Column(Integer, nullable=True)  # 体重(kg)  
    gender = Column(String(10), nullable=False, default='male')  # 添加性别字段
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# 新增 Model 表映射
class Model(Base):
    __tablename__ = "models"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    filename = Column(String(255), nullable=False)
    glb_url = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="models")

# 头像表模型
class Avatar(Base):
    __tablename__ = "avatars"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    filename = Column(String(255), nullable=False)  # 头像文件名
    file_path = Column(String(500), nullable=False)  # 头像文件路径
    is_current = Column(Integer, default=1)  # 是否为当前头像
    created_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="avatars")


User.models = relationship("Model", back_populates="user", cascade="all, delete-orphan")
User.avatars = relationship("Avatar", back_populates="user", cascade="all, delete-orphan") 